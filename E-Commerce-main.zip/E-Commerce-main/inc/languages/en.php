<?php
$lang = [
  'Said Lagauit' => 'Said Lagauit',
  'Ltr' => 'Ltr',
  'En' => 'en',
  'Bootstrap' => 'bootstrap.min.css',
  'English' => 'English',
  'Arabic' => 'Arabic',
  'Shop' => 'Shop',
  'FAQ' => 'FAQ',
  'Tracking' => 'Tracking',
  'Contact Us' => 'Contact Us',
  'Search' => 'Search',
  'Said Lagauit Store' => 'Said Lagauit Store',
  'Last Products' => 'Last Products',
  '' => ''
];
