<?php
$lang = [
  'Said Lagauit' => 'سعيد لكويط',
  'Ltr' => 'rtl',
  'En' => 'en',
  'Bootstrap' => 'bootstrap.rtl.min.css',
  'English' => 'انجليزي',
  'Arabic' => 'عربي',
  'Shop' => 'متجر',
  'FAQ' => 'أسئلة شائعة',
  'Tracking' => 'تتبع',
  'Contact Us' => 'اتصل بنا',
  'Search' => 'بحث',
  'Said Lagauit Store' => 'متجر سعيد لكويط',
  'Last Products' => 'آخر المنتجات'
];
