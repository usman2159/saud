<footer class="py-5 my-2 bg-body-tertiary text-center position-relative">
  <div class="container">
    <p>&copy; <?php echo date('Y') . ' - ' . $lang['Said Lagauit Store']; ?></p>
  </div>
</footer>
<script src="<?php echo $js ?>jquery-3.7.0.min.js"></script>
<script src="<?php echo $js ?>bootstrap.bundle.min.js"></script>
<script src="<?php echo $js ?>main.js"></script>

</body>

</html>